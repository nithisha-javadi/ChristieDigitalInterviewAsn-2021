import { Component, OnInit } from '@angular/core';
import { PictureSelectionService, DropDownData, DropDownOption } from './services/picture-selection.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})

// Generic Angular starting point: the html/scss hold the page 
// structure, with control and map panes that do the actual work

export class AppComponent implements OnInit{
    public picData: DropDownData;
    public selectedValue:any;
    public response:any;
    public imgValueObj:any;
    constructor( private pictureSelectionSerice: PictureSelectionService ) {
       
    }
    ngOnInit() {
        this.pictureSelectionSerice.getDropDownList().then( res => { // Success
            const people = [];
            this.response=res;
            for(let i=0;i<this.response.options.length;i++){
              people.push(new DropDownOption(this.response.options[i].index, this.response.options[i].label,this.response.options[i].value));
            }
            this.picData=new DropDownData(people,this.response.selectedIndex,this.response.disabled);
            this.selectedValue=this.picData.selectedIndex;
            this.imgValueObj=this.response.options.filter(boxer => boxer.index === this.selectedValue)[0];
          }
        );
      }
      public onBoxerChange(selectedValue) {
        this.selectedValue=parseInt(selectedValue);
        this.imgValueObj=this.response.options.filter(boxer => boxer.index === this.selectedValue)[0];
     }

}
